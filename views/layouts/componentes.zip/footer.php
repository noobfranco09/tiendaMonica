 <?php require_once $_SERVER['DOCUMENT_ROOT'] .'/tiendaMonica/rutas/rutaGlobal.php' ?>
<!-- footer.php -->
<footer class="text-center mt-5">
    <div class="container">
        <p>&copy; <?= date('Y') ?> Tienda Artística. Todos los derechos reservados.</p>
    </div>
</footer>

<!-- JS Bootstrap local -->
<script src="<?php echo BASE_URL.'assets/js/bootstrap.bundle.js' ?>"></script>
