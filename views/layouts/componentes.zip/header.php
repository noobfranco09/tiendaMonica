     <!-- header.php -->
<header class="text-center py-4">
    <h1 class="m-0">Tienda Artística</h1>
    <p class="m-0">Camisetas estampadas, vasos, arte y más</p>
</header>